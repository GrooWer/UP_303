﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace uch_prakt_19._02
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("Пожалуйста, заполните все поля для регистрации!!!");
                }
                else
                {
                    SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-MKHQRMV\SQLEXPRESS;Initial Catalog=Pohoj_Na_Abonenta; Integrated Security=True;");
                    con.Open();
                    string str = "insert into Login(Login,Password) values ('" + textBox1.Text + "','" + textBox2.Text + "')";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Пользователь зарегистрирован!!!");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3.ActiveForm.Hide();
            Form1 MyForm1 = new Form1();
            MyForm1.ShowDialog();
            Close();
        }
    }
}
