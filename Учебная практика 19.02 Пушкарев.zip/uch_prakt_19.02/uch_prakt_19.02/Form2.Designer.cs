﻿
namespace uch_prakt_19._02
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.pohoj_Na_AbonentaDataSet = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSet();
            this.абонентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.абонентTableAdapter = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSetTableAdapters.АбонентTableAdapter();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pohoj_Na_AbonentaDataSet1 = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSet1();
            this.операторBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.операторTableAdapter = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSet1TableAdapters.ОператорTableAdapter();
            this.pohoj_Na_AbonentaDataSet2 = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSet2();
            this.телефонBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.телефонTableAdapter = new uch_prakt_19._02.Pohoj_Na_AbonentaDataSet2TableAdapters.ТелефонTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.абонентBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(717, 310);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(177, 422);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(301, 422);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 30);
            this.button2.TabIndex = 2;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(428, 422);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 30);
            this.button3.TabIndex = 3;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(12, 441);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(59, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Назад";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pohoj_Na_AbonentaDataSet
            // 
            this.pohoj_Na_AbonentaDataSet.DataSetName = "Pohoj_Na_AbonentaDataSet";
            this.pohoj_Na_AbonentaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // абонентBindingSource
            // 
            this.абонентBindingSource.DataMember = "Абонент";
            this.абонентBindingSource.DataSource = this.pohoj_Na_AbonentaDataSet;
            // 
            // абонентTableAdapter
            // 
            this.абонентTableAdapter.ClearBeforeFill = true;
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(630, 352);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 5;
            this.button5.Text = "Оператор";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(630, 381);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "Телефон";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(630, 323);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "Абонент";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pohoj_Na_AbonentaDataSet1
            // 
            this.pohoj_Na_AbonentaDataSet1.DataSetName = "Pohoj_Na_AbonentaDataSet1";
            this.pohoj_Na_AbonentaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // операторBindingSource
            // 
            this.операторBindingSource.DataMember = "Оператор";
            this.операторBindingSource.DataSource = this.pohoj_Na_AbonentaDataSet1;
            // 
            // операторTableAdapter
            // 
            this.операторTableAdapter.ClearBeforeFill = true;
            // 
            // pohoj_Na_AbonentaDataSet2
            // 
            this.pohoj_Na_AbonentaDataSet2.DataSetName = "Pohoj_Na_AbonentaDataSet2";
            this.pohoj_Na_AbonentaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // телефонBindingSource
            // 
            this.телефонBindingSource.DataMember = "Телефон";
            this.телефонBindingSource.DataSource = this.pohoj_Na_AbonentaDataSet2;
            // 
            // телефонTableAdapter
            // 
            this.телефонTableAdapter.ClearBeforeFill = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 476);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "Работа";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.абонентBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.операторBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pohoj_Na_AbonentaDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.телефонBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private Pohoj_Na_AbonentaDataSet pohoj_Na_AbonentaDataSet;
        private System.Windows.Forms.BindingSource абонентBindingSource;
        private Pohoj_Na_AbonentaDataSetTableAdapters.АбонентTableAdapter абонентTableAdapter;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private Pohoj_Na_AbonentaDataSet1 pohoj_Na_AbonentaDataSet1;
        private System.Windows.Forms.BindingSource операторBindingSource;
        private Pohoj_Na_AbonentaDataSet1TableAdapters.ОператорTableAdapter операторTableAdapter;
        private Pohoj_Na_AbonentaDataSet2 pohoj_Na_AbonentaDataSet2;
        private System.Windows.Forms.BindingSource телефонBindingSource;
        private Pohoj_Na_AbonentaDataSet2TableAdapters.ТелефонTableAdapter телефонTableAdapter;
    }
}