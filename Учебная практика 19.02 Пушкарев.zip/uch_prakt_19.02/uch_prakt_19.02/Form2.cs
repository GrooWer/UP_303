﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace uch_prakt_19._02
{
    public partial class Form2 : Form
    {
        DataSet ds;
        SqlDataAdapter adapter;
        SqlCommandBuilder commandBuilder;
        string connectionString = @"Data Source=DESKTOP-MKHQRMV\SQLEXPRESS;Initial Catalog=Pohoj_Na_Abonenta;Integrated Security=True";
        string sql = "SELECT * FROM Абонент,Оператор,Телефон";
        public Form2()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToAddRows = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                adapter = new SqlDataAdapter(sql, connection);

                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];

            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pohoj_Na_AbonentaDataSet2.Телефон". При необходимости она может быть перемещена или удалена.
            this.телефонTableAdapter.Fill(this.pohoj_Na_AbonentaDataSet2.Телефон);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pohoj_Na_AbonentaDataSet1.Оператор". При необходимости она может быть перемещена или удалена.
            this.операторTableAdapter.Fill(this.pohoj_Na_AbonentaDataSet1.Оператор);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pohoj_Na_AbonentaDataSet.Абонент". При необходимости она может быть перемещена или удалена.
            this.абонентTableAdapter.Fill(this.pohoj_Na_AbonentaDataSet.Абонент);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = операторBindingSource;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = абонентBindingSource;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = телефонBindingSource;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2.ActiveForm.Hide();
            Form1 MyForm1 = new Form1();
            MyForm1.ShowDialog();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource == операторBindingSource)
            {
                DataRow row = ds.Tables[0].NewRow(); // добавляем новую строку в DataTable
                ds.Tables[0].Rows.Add(row);
            }
        }
    }
}
